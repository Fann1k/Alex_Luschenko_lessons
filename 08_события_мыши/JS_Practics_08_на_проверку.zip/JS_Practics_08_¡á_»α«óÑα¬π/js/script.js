//добавляем событие dblclick
document.querySelector('.ondblclick').ondblclick = function () {
    console.log('dblclick');
}

//отменяем выделение при двойном нажатии
document.querySelector('.ondblclick').onmousedown = function () {
    return false;
}

//отключаем ПКМ
document.querySelector('html').oncontextmenu = function () {
    console.log('Клик правой кнопкой мыши на документе отключен');
    return false;
}


//имитация открытия и закрытия папки
document.querySelector('.folder').onmouseenter = function () {
    document.querySelector('.folder-open').style.display = 'block';
    document.querySelector('.folder-close').style.display = 'none';
}

document.querySelector('.folder').onmouseleave = function () {
    document.querySelector('.folder-open').style.display = 'none';
    document.querySelector('.folder-close').style.display = 'block';
}

//окрашивание блоков
document.querySelector('.bg-color1').onmouseenter = function () {
    let a = Math.floor(Math.random() * 256);
    let b = Math.floor(Math.random() * 256);
    let c = Math.floor(Math.random() * 256);
    document.querySelector('.bg-color1').style.backgroundColor = `rgb(${a}, ${b}, ${c})`;
}

document.querySelector('.bg-color2').onmouseenter = function () {
    let a = Math.floor(Math.random() * 256);
    let b = Math.floor(Math.random() * 256);
    let c = Math.floor(Math.random() * 256);
    document.querySelector('.bg-color2').style.backgroundColor = `rgb(${a}, ${b}, ${c})`;
}

document.querySelector('.bg-color3').onmouseenter = function () {
    let a = Math.floor(Math.random() * 256);
    let b = Math.floor(Math.random() * 256);
    let c = Math.floor(Math.random() * 256);
    document.querySelector('.bg-color3').style.backgroundColor = `rgb(${a}, ${b}, ${c})`;
}

