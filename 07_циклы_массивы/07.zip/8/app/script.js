for (let i = 1000; i < 2001; i++) {
    document.querySelector('#output').innerHTML += `&#${i}`;
}