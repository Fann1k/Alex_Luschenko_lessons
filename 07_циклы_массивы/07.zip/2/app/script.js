for (let i = 0; i <= 101; i++) {
    if (i % 2 == 0) {
        document.querySelector('#output').innerHTML += ' ' + i;
    }
}