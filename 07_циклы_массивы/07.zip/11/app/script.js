let span = document.querySelectorAll('span');

for (let i = 0; i < span.length; i++) {
    span[i].style.backgroundColor = 'yellow';
}