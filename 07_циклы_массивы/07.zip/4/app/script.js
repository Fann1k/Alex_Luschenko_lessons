let sum = 0;
for (let i = 0; i < 101; i++) {
    sum += i;
    document.querySelector('#output').innerHTML = sum;
}