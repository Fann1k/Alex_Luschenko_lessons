for (let i = 200; i > -1; i--) {
    document.querySelector('#output').innerHTML += ' ' + i;
}