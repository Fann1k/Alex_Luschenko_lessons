let year = 1993;
console.log(2018 - year);

p = document.querySelector('#out');
p.innerText = 2018 - year;
c = 2018 - year;
p.innerHTML = <i>c</i>;